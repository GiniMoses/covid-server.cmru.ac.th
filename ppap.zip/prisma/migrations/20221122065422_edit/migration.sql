-- AlterTable
ALTER TABLE `Personal` MODIFY `dateAdd` DATETIME(3) NULL;
